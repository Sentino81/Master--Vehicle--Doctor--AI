package com.mastervehicledoctor.ai;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {
    private LinearLayout root;
    private TextView status, report;
    private EditText symptoms, wifiHost, wifiPort;
    private Socket wifiSocket;
    private BluetoothSocket bluetoothSocket;
    private InputStream input;
    private OutputStream output;
    private volatile boolean connected = false;
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private final int blue = Color.rgb(18, 87, 119);

    @Override public void onCreate(Bundle state) { super.onCreate(state); buildScreen(); }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private TextView label(String text, int size, boolean bold) {
        TextView t = new TextView(this); t.setText(text); t.setTextSize(size); t.setTextColor(Color.rgb(28,39,52));
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); t.setPadding(0,dp(5),0,dp(5)); return t;
    }
    private Button button(String text) { Button b = new Button(this); b.setText(text); b.setAllCaps(false); b.setTextSize(15); return b; }
    private LinearLayout.LayoutParams full() { return new LinearLayout.LayoutParams(-1,-2); }
    private void addButton(String text, Runnable action) { Button b=button(text); root.addView(b,full()); b.setOnClickListener(v->action.run()); }
    private void buildScreen() {
        ScrollView scroll = new ScrollView(this); root = new LinearLayout(this); root.setOrientation(1); root.setPadding(dp(18),dp(18),dp(18),dp(26)); root.setBackgroundColor(Color.rgb(245,248,251)); scroll.addView(root);
        TextView title=label("MASTER VEHICLE DOCTOR AI",23,true); title.setTextColor(blue); root.addView(title);
        root.addView(label("OBD-II scanner • troubleshooting • repair guidance",14,false));
        TextView version=label("DIAGNOSTIC EDITION • v0.2.0",12,true); version.setTextColor(Color.rgb(17,110,80)); root.addView(version);
        root.addView(label("Scanner connection",19,true));
        status=label("Status: Not connected. Connect a compatible ELM327 OBD-II adapter.",14,true); root.addView(status);
        addButton("🔵 Connect Bluetooth OBD-II adapter", this::chooseBluetooth);
        root.addView(label("Wi-Fi adapter settings",16,true));
        wifiHost=new EditText(this); wifiHost.setSingleLine(true); wifiHost.setHint("Adapter IP address (example: 192.168.0.10)"); wifiHost.setText("192.168.0.10"); root.addView(wifiHost,full());
        wifiPort=new EditText(this); wifiPort.setSingleLine(true); wifiPort.setInputType(2); wifiPort.setHint("Port (commonly 35000 or 23)"); wifiPort.setText("35000"); root.addView(wifiPort,full());
        addButton("📶 Connect Wi-Fi OBD-II adapter", this::connectWifi);
        addButton("🔌 USB adapter information", () -> message("USB connection", "USB OBD-II support depends on the adapter chipset and USB serial driver. This build does not yet communicate with USB adapters. Bluetooth classic ELM327 and Wi-Fi ELM327 are the first supported connection paths."));
        root.addView(label("Run diagnostics",19,true));
        addButton("🧰 Read trouble codes (Mode 03)", () -> sendObd("03", "Diagnostic Trouble Codes"));
        addButton("📊 Read engine live data", this::readLiveData);
        addButton("🧹 Clear trouble codes (Mode 04)", () -> new AlertDialog.Builder(this).setTitle("Clear fault codes?").setMessage("This can erase stored codes and readiness information. Fix the cause first. Continue only if you understand the consequences.").setNegativeButton("Cancel",null).setPositiveButton("Clear codes",(d,w)->sendObd("04","Clear trouble codes")).show());
        root.addView(label("AI Vehicle Doctor — symptom checker",19,true));
        symptoms=new EditText(this); symptoms.setMinLines(3); symptoms.setGravity(48); symptoms.setHint("Describe symptoms, e.g. engine cranks but will not start, overheating, rough idle..."); root.addView(symptoms,full());
        addButton("🤖 Analyse symptoms", this::analyseSymptoms);
        root.addView(label("Diagnostic report",19,true));
        report=label("No report yet. Connect an adapter to read vehicle data, or describe symptoms above.",14,false); report.setPadding(dp(12),dp(12),dp(12),dp(12)); report.setBackgroundColor(Color.WHITE); root.addView(report,full());
        root.addView(label("Safety: Never work under a vehicle supported only by a jack. Do not clear codes before recording them. OBD-II coverage varies by vehicle; ABS, airbag, transmission and manufacturer-specific modules may require enhanced tools.",12,false));
        setContentView(scroll);
    }
    private void uiStatus(String text) { runOnUiThread(()->status.setText("Status: "+text)); }
    private void uiReport(String text) { runOnUiThread(()->report.setText(text)); }
    private void message(String title,String body) { new AlertDialog.Builder(this).setTitle(title).setMessage(body).setPositiveButton("OK",null).show(); }
    private void chooseBluetooth() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN}, 101); return;
        }
        BluetoothAdapter adapter=BluetoothAdapter.getDefaultAdapter();
        if(adapter==null){message("Bluetooth unavailable","This phone does not provide Bluetooth support.");return;}
        if(!adapter.isEnabled()){message("Turn on Bluetooth","Turn on Bluetooth in your phone settings, pair your ELM327 adapter, then try again.");return;}
        try {
            Set<BluetoothDevice> paired=adapter.getBondedDevices(); ArrayList<BluetoothDevice> devices=new ArrayList<>(); ArrayList<String> names=new ArrayList<>();
            for(BluetoothDevice d:paired){devices.add(d); names.add((d.getName()==null?"Bluetooth device":d.getName())+"\n"+d.getAddress());}
            if(devices.isEmpty()){message("No paired adapters","Open Bluetooth settings and pair your ELM327 adapter first.");return;}
            new AlertDialog.Builder(this).setTitle("Choose paired OBD-II adapter").setItems(names.toArray(new String[0]),(dialog,which)->connectBluetooth(devices.get(which))).setNegativeButton("Cancel",null).show();
        } catch(SecurityException e){message("Bluetooth permission required","Allow Nearby devices/Bluetooth permission, then retry.");}
    }
    private void connectBluetooth(BluetoothDevice device) {
        uiStatus("Connecting to Bluetooth adapter..."); new Thread(()->{
            try { BluetoothSocket s=device.createRfcommSocketToServiceRecord(SPP_UUID); s.connect(); bluetoothSocket=s; input=s.getInputStream(); output=s.getOutputStream(); connected=true; uiStatus("Connected by Bluetooth to "+device.getName()); initializeElm(); }
            catch(Exception e){connected=false; uiStatus("Bluetooth connection failed: "+e.getMessage());}
        }).start();
    }
    private void connectWifi() {
        String host=wifiHost.getText().toString().trim(); int port;
        try{port=Integer.parseInt(wifiPort.getText().toString().trim()); if(port<1||port>65535)throw new Exception();}catch(Exception e){message("Check port","Enter a valid port from 1 to 65535.");return;}
        if(host.isEmpty()){message("Check IP address","Enter the Wi-Fi adapter's IP address.");return;}
        uiStatus("Connecting to Wi-Fi adapter..."); final int p=port; new Thread(()->{
            try { Socket s=new Socket(); s.connect(new InetSocketAddress(host,p),5000); wifiSocket=s; input=s.getInputStream(); output=s.getOutputStream(); connected=true; uiStatus("Connected by Wi-Fi to "+host+":"+p); initializeElm(); }
            catch(Exception e){connected=false;uiStatus("Wi-Fi connection failed: "+e.getMessage()+". Check adapter IP, port and same Wi-Fi network.");}
        }).start();
    }
    private synchronized String command(String cmd) throws Exception {
        if(!connected||output==null||input==null) throw new Exception("Connect an OBD-II adapter first.");
        while(input.available()>0) input.read(); output.write((cmd+"\r").getBytes(StandardCharsets.US_ASCII)); output.flush();
        StringBuilder out=new StringBuilder(); long end=System.currentTimeMillis()+3500;
        while(System.currentTimeMillis()<end){ if(input.available()>0){int c=input.read(); if(c<0)break; if(c=='>' )break; if(c!='\r'&&c!='\n')out.append((char)c);} else {Thread.sleep(40);} }
        return out.toString().trim();
    }
    private void initializeElm(){try{command("ATZ");Thread.sleep(900);command("ATE0");command("ATL0");command("ATS0");command("ATH0");String r=command("0100");uiReport("Adapter initialized. Vehicle protocol response to 0100:\n"+r+"\n\nIf the response says UNABLE TO CONNECT or NO DATA, switch ignition on and check adapter compatibility.");}catch(Exception e){uiReport("Adapter connected, but initialization/vehicle communication failed: "+e.getMessage());}}
    private void sendObd(String cmd,String title){ if(!connected){message("Scanner not connected","Connect a compatible Bluetooth or Wi-Fi ELM327 adapter first.");return;} uiStatus("Requesting "+title+"..."); new Thread(()->{try{String r=command(cmd);uiReport(title+"\nOBD-II command: "+cmd+"\nRaw adapter response:\n"+r+"\n\nNote: raw responses are shown in this version; manufacturer-specific interpretation may require enhanced diagnostics.");uiStatus("Connected; request completed.");}catch(Exception e){uiReport(title+" failed: "+e.getMessage());}}).start(); }
    private void readLiveData(){ if(!connected){message("Scanner not connected","Connect an OBD-II adapter first.");return;} uiStatus("Reading live engine data..."); new Thread(()->{try{String rpm=command("010C");String speed=command("010D");String temp=command("0105");String load=command("0104");uiReport("LIVE ENGINE DATA\nEngine RPM (010C): "+rpm+"\nVehicle speed (010D): "+speed+"\nCoolant temperature (0105): "+temp+"\nCalculated engine load (0104): "+load+"\n\nValues are raw adapter responses in this version. Confirm the engine is running when appropriate and keep attention on the road; never read the screen while driving.");}catch(Exception e){uiReport("Live data request failed: "+e.getMessage());}}).start(); }
    private void analyseSymptoms(){String s=symptoms.getText().toString().toLowerCase().trim(); if(s.isEmpty()){message("Describe the problem","Enter the vehicle symptoms first.");return;} StringBuilder r=new StringBuilder("MASTER VEHICLE DOCTOR AI — PRELIMINARY SYMPTOM REPORT\n\nSymptoms entered: ").append(symptoms.getText().toString()).append("\n\nLikely areas to check (not a confirmed diagnosis):\n");
        if(s.contains("overheat")||s.contains("hot")||s.contains("temperature"))r.append("1. Cooling system: coolant level/leaks, radiator fan, thermostat, radiator blockage, water pump. Stop driving if temperature is high.\n");
        if(s.contains("crank")||s.contains("start")||s.contains("starting")||s.contains("won't start")||s.contains("will not start"))r.append("1. Starting/no-start: battery voltage and terminals, starter circuit, fuel supply, ignition, immobilizer and crank/cam sensors. Note whether engine cranks.\n");
        if(s.contains("rough")||s.contains("misfire")||s.contains("shake")||s.contains("vibrat"))r.append("1. Rough running: scan for DTCs, inspect ignition coils/plugs, intake leaks, fuel delivery and engine mounts.\n");
        if(s.contains("smoke")||s.contains("burn"))r.append("1. Smoke/burning smell: stop safely if smoke is heavy or there is a fire risk. Check oil/coolant leaks and wiring only when safe.\n");
        if(s.contains("brake")||s.contains("steering"))r.append("1. Brake/steering concern: safety-critical. Do not drive if braking or steering is impaired; arrange professional inspection.\n");
        if(s.contains("battery")||s.contains("light")||s.contains("electrical"))r.append("1. Electrical: battery condition, charging voltage, fuses, grounds and alternator output.\n");
        r.append("\nRecommended next steps:\n• Record dashboard warning lights and all fault codes before clearing anything.\n• Check fluid levels only using the owner's manual and safe procedures.\n• Confirm diagnosis with measurements and a qualified technician.\n\nThis is rule-based guidance, not a cloud AI diagnosis. Parts/labour prices depend on vehicle, location and parts quality; no estimate is supplied without vehicle details."); uiReport(r.toString()); }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results){super.onRequestPermissionsResult(requestCode,permissions,results);if(requestCode==101){if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)chooseBluetooth();else message("Permission needed","Allow Bluetooth/Nearby devices permission to connect an adapter.");}}
    @Override protected void onDestroy(){super.onDestroy();connected=false;try{if(bluetoothSocket!=null)bluetoothSocket.close();}catch(Exception ignored){}try{if(wifiSocket!=null)wifiSocket.close();}catch(Exception ignored){}}
}
