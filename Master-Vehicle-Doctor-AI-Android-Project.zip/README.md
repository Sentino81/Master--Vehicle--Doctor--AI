# Master Vehicle Doctor AI — Android starter project

This is the initial Android project and automatic APK build workflow.

## Current starter features
- Android dashboard
- Symptom-based troubleshooting for several common symptom groups
- Clear safety notices
- GitHub Actions workflow that builds a debug APK and uploads it as an artifact

## Important limitations
This first build is **not yet a working electronic vehicle scanner**. Bluetooth/Wi-Fi/USB OBD2 communication, live sensor readings, actual fault-code retrieval, advanced modules (ABS/airbags/transmission), persistent vehicle history, and AI/cloud diagnosis still need implementation and testing with real adapters and vehicles. Symptom results are general guidance only.

## Build an APK using GitHub Actions
1. Create a GitHub repository named `Master-Vehicle-Doctor-AI`.
2. Upload all files in this project to the repository, keeping the folder structure.
3. Open the repository's **Actions** tab.
4. Select **Build Master Vehicle Doctor AI APK**.
5. Tap **Run workflow** and confirm.
6. When the workflow completes successfully, open the run and download the `Master-Vehicle-Doctor-AI-APK` artifact.
7. Extract the downloaded ZIP to obtain `app-debug.apk`.

## Requirements
- Android Studio / Android Gradle Plugin 8.7.3 for local development
- JDK 17
- Gradle 8.9
- Android SDK platform 35

## Next development milestone
Implement an OBD2 adapter abstraction, starting with one documented ELM327-compatible Bluetooth adapter and a safe read-only workflow (connect, request supported PIDs, read DTCs, clear DTCs only after explicit confirmation and with appropriate warnings). Then add Wi-Fi and USB transports and vehicle-specific enhanced diagnostics where hardware/protocol support exists.
