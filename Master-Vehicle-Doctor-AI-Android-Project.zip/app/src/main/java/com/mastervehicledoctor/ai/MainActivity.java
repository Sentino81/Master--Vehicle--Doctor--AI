package com.mastervehicledoctor.ai;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

public class MainActivity extends Activity {
    private LinearLayout root;
    private TextView status;
    private EditText symptoms;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        buildScreen();
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView label(String text, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(size);
        t.setTextColor(Color.rgb(28, 39, 52));
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setPadding(0, dp(5), 0, dp(5));
        return t;
    }

    private Button button(String text) {
        Button b = new Button(this);
        b.setText(text);
        b.setAllCaps(false);
        b.setTextSize(15);
        return b;
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(20), dp(20), dp(20), dp(24));
        root.setBackgroundColor(Color.rgb(245, 248, 251));
        scroll.addView(root);

        TextView brand = label("MASTER VEHICLE DOCTOR AI", 22, true);
        brand.setTextColor(Color.rgb(17, 83, 112));
        root.addView(brand);
        root.addView(label("Your intelligent vehicle troubleshooting assistant", 14, false));

        TextView badge = label("STARTER VERSION • v0.1.0", 12, true);
        badge.setTextColor(Color.rgb(17, 110, 80));
        root.addView(badge);

        root.addView(label("Choose a diagnostic tool", 19, true));

        Button scan = button("🔌  Connect scanner / Auto Scan");
        root.addView(scan, matchWrap());
        scan.setOnClickListener(v -> showScannerInfo());

        Button symptom = button("🧠  AI Vehicle Doctor — Symptom Checker");
        root.addView(symptom, matchWrap());
        symptom.setOnClickListener(v -> showSymptoms());

        Button live = button("📊  Live Data");
        root.addView(live, matchWrap());
        live.setOnClickListener(v -> showMessage("Live Data", "Live sensor readings will be available after a compatible OBD2 adapter connection is implemented and tested."));

        Button vehicles = button("🚘  My Vehicles");
        root.addView(vehicles, matchWrap());
        vehicles.setOnClickListener(v -> showMessage("My Vehicles", "Vehicle profiles and saved scan history are planned for a later build."));

        Button reports = button("📄  Diagnostic Reports");
        root.addView(reports, matchWrap());
        reports.setOnClickListener(v -> showMessage("Diagnostic Reports", "Report export will be added after real scan results and vehicle profiles are implemented."));

        status = label("Ready. No vehicle scan has been performed.", 14, false);
        status.setPadding(dp(12), dp(12), dp(12), dp(12));
        status.setBackgroundColor(Color.rgb(229, 239, 245));
        root.addView(status);

        root.addView(label("Safety note", 16, true));
        root.addView(label("This starter build does not yet communicate with a vehicle. Symptom results are general guidance, not a confirmed diagnosis. Stop driving if the vehicle has a serious warning, braking/steering failure, overheating, or a flashing check-engine light.", 13, false));
        setContentView(scroll);
    }

    private LinearLayout.LayoutParams matchWrap() {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT);
        p.setMargins(0, dp(4), 0, dp(4));
        return p;
    }

    private void showScannerInfo() {
        showMessage("Scanner connection",
                "The scanner screen is prepared, but real Bluetooth, Wi-Fi and USB OBD2 communication is not implemented in this starter build. Next development step: select a supported adapter protocol, then add connection, code-reading and live-data tests.");
    }

    private void showSymptoms() {
        root.removeView(symptoms);
        symptoms = new EditText(this);
        symptoms.setHint("Describe the problem (e.g. cranks but won't start)");
        symptoms.setMinLines(2);
        symptoms.setGravity(Gravity.TOP | Gravity.START);
        root.addView(label("Describe your vehicle's symptoms", 16, true));
        root.addView(symptoms, matchWrap());

        Button diagnose = button("Analyse symptoms");
        root.addView(diagnose, matchWrap());
        diagnose.setOnClickListener(v -> analyseSymptoms());
        symptoms.requestFocus();
    }

    private void analyseSymptoms() {
        String s = symptoms.getText().toString().trim().toLowerCase();
        if (s.isEmpty()) {
            status.setText("Please describe the symptoms first.");
            return;
        }
        String result;
        if (s.contains("overheat") || s.contains("hot") || s.contains("temperature")) {
            result = "Possible causes: low coolant, cooling-fan fault, thermostat issue, radiator restriction or water-pump problem. SAFETY: safely stop the vehicle and switch off the engine if it is overheating. Never open a hot radiator cap.";
        } else if (s.contains("crank") && (s.contains("start") || s.contains("starting"))) {
            result = "Possible causes: weak battery or poor connections, fuel delivery issue, ignition fault, crank/cam sensor issue or low compression. Check battery condition and whether the engine cranks at normal speed; further tests are needed to narrow this down.";
        } else if (s.contains("battery") || s.contains("won't turn") || s.contains("wont turn") || s.contains("click")) {
            result = "Possible causes: discharged battery, loose/corroded battery terminals, starter motor/solenoid fault or charging-system issue. Check terminal security and battery voltage; avoid shorting battery terminals.";
        } else if (s.contains("smoke")) {
            result = "Smoke colour and conditions matter. Blue smoke may indicate oil burning; persistent white smoke may indicate coolant entering the combustion chamber; black smoke may indicate excess fuel. Stop if smoke is heavy, the engine overheats, or there is a fire/fuel smell.";
        } else if (s.contains("stall") || s.contains("stops") || s.contains("shut off")) {
            result = "Possible causes: fuel supply, air intake, ignition, sensor or charging-system problems. Note whether it happens at idle, while accelerating or when hot, and scan for fault codes if possible.";
        } else if (s.contains("power") || s.contains("slow") || s.contains("acceleration")) {
            result = "Possible causes: restricted air/fuel supply, ignition misfire, exhaust restriction, boost leak (if turbocharged) or limp mode. Read fault codes and inspect the air filter and warning lights before replacing parts.";
        } else {
            result = "Start with these checks: note warning lights, listen for unusual noises, inspect for visible leaks, check fluid levels when safe, and read OBD2 fault codes if an adapter is available. This symptom needs more detail to rank causes reliably.";
        }
        status.setText("SYMPTOM REVIEW — not a confirmed diagnosis\n\n" + result);
    }

    private void showMessage(String title, String message) {
        status.setText(title + "\n\n" + message);
    }
}
