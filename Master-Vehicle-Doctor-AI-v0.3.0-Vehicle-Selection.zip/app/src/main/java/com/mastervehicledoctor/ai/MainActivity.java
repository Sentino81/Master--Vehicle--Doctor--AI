package com.mastervehicledoctor.ai;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Set;
import java.util.UUID;

public class MainActivity extends Activity {
    private LinearLayout root;
    private TextView status, report;
    private EditText symptoms, wifiHost, wifiPort, vehicleMake, vehicleModel, vehicleYear, vinInput;
    private Socket wifiSocket;
    private BluetoothSocket bluetoothSocket;
    private InputStream input;
    private OutputStream output;
    private volatile boolean connected = false;
    private static final UUID SPP_UUID = UUID.fromString("00001101-0000-1000-8000-00805F9B34FB");
    private final int blue = Color.rgb(18, 87, 119);

    @Override public void onCreate(Bundle state) { super.onCreate(state); buildScreen(); }
    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private TextView label(String text, int size, boolean bold) {
        TextView t = new TextView(this); t.setText(text); t.setTextSize(size); t.setTextColor(Color.rgb(28,39,52));
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD); t.setPadding(0,dp(5),0,dp(5)); return t;
    }
    private Button button(String text) { Button b = new Button(this); b.setText(text); b.setAllCaps(false); b.setTextSize(15); return b; }
    private LinearLayout.LayoutParams full() { return new LinearLayout.LayoutParams(-1,-2); }
    private void addButton(String text, Runnable action) { Button b=button(text); root.addView(b,full()); b.setOnClickListener(v->action.run()); }
    private void buildScreen() {
        ScrollView scroll = new ScrollView(this); root = new LinearLayout(this); root.setOrientation(1); root.setPadding(dp(18),dp(18),dp(18),dp(26)); root.setBackgroundColor(Color.rgb(245,248,251)); scroll.addView(root);
        TextView title=label("MASTER VEHICLE DOCTOR AI",23,true); title.setTextColor(blue); root.addView(title);
        root.addView(label("OBD-II scanner • troubleshooting • repair guidance",14,false));
        TextView version=label("DIAGNOSTIC EDITION • v0.3.0",12,true); version.setTextColor(Color.rgb(17,110,80)); root.addView(version);
        root.addView(label("Vehicle Selection — Manual or VIN",19,true));
        root.addView(label("Manual selection works for any make. VIN decoding below provides a preliminary year/region/manufacturer hint; it is not a complete factory lookup.",13,false));
        vehicleMake=new EditText(this); vehicleMake.setSingleLine(true); vehicleMake.setHint("Vehicle make (e.g. Toyota, Nissan, Ford)"); root.addView(vehicleMake,full());
        vehicleModel=new EditText(this); vehicleModel.setSingleLine(true); vehicleModel.setHint("Model (e.g. Corolla, Navara, Ranger)"); root.addView(vehicleModel,full());
        vehicleYear=new EditText(this); vehicleYear.setSingleLine(true); vehicleYear.setInputType(2); vehicleYear.setHint("Model year (e.g. 2018)"); root.addView(vehicleYear,full());
        addButton("Save manual vehicle selection", this::saveManualVehicle);
        vinInput=new EditText(this); vinInput.setSingleLine(true); vinInput.setHint("Enter 17-character VIN"); root.addView(vinInput,full());
        addButton("Check VIN (basic offline decode)", this::decodeVin);
        root.addView(label("Scanner connection",19,true));
        status=label("Status: Not connected. Connect a compatible ELM327 OBD-II adapter.",14,true); root.addView(status);
        addButton("🔵 Connect Bluetooth OBD-II adapter", this::chooseBluetooth);
        root.addView(label("Wi-Fi adapter settings",16,true));
        wifiHost=new EditText(this); wifiHost.setSingleLine(true); wifiHost.setHint("Adapter IP address (example: 192.168.0.10)"); wifiHost.setText("192.168.0.10"); root.addView(wifiHost,full());
        wifiPort=new EditText(this); wifiPort.setSingleLine(true); wifiPort.setInputType(2); wifiPort.setHint("Port (commonly 35000 or 23)"); wifiPort.setText("35000"); root.addView(wifiPort,full());
        addButton("📶 Connect Wi-Fi OBD-II adapter", this::connectWifi);
        addButton("🔌 USB adapter information", () -> message("USB connection", "USB OBD-II support depends on the adapter chipset and USB serial driver. This build does not yet communicate with USB adapters. Bluetooth classic ELM327 and Wi-Fi ELM327 are the first supported connection paths."));
        root.addView(label("Run diagnostics",19,true));
        addButton("🧰 Read trouble codes (Mode 03)", () -> sendObd("03", "Diagnostic Trouble Codes"));
        addButton("📊 Read engine live data", this::readLiveData);
        addButton("🧹 Clear trouble codes (Mode 04)", () -> new AlertDialog.Builder(this).setTitle("Clear fault codes?").setMessage("This can erase stored codes and readiness information. Fix the cause first. Continue only if you understand the consequences.").setNegativeButton("Cancel",null).setPositiveButton("Clear codes",(d,w)->sendObd("04","Clear trouble codes")).show());
        root.addView(label("AI Vehicle Doctor — symptom checker",19,true));
        symptoms=new EditText(this); symptoms.setMinLines(3); symptoms.setGravity(48); symptoms.setHint("Describe symptoms, e.g. engine cranks but will not start, overheating, rough idle..."); root.addView(symptoms,full());
        addButton("🤖 Analyse symptoms", this::analyseSymptoms);
        root.addView(label("Diagnostic report",19,true));
        report=label("No report yet. Connect an adapter to read vehicle data, or describe symptoms above.",14,false); report.setPadding(dp(12),dp(12),dp(12),dp(12)); report.setBackgroundColor(Color.WHITE); root.addView(report,full());
        root.addView(label("Safety: Never work under a vehicle supported only by a jack. Do not clear codes before recording them. OBD-II coverage varies by vehicle; ABS, airbag, transmission and manufacturer-specific modules may require enhanced tools.",12,false));
        setContentView(scroll);
    }
    private void saveManualVehicle() {
        String make=vehicleMake.getText().toString().trim();
        String model=vehicleModel.getText().toString().trim();
        String year=vehicleYear.getText().toString().trim();
        if(make.isEmpty() || model.isEmpty() || year.isEmpty()) { message("Vehicle details needed","Enter the make, model and year to create a preliminary vehicle profile."); return; }
        uiReport("VEHICLE PROFILE\nMake: "+make+"\nModel: "+model+"\nYear: "+year+"\n\nThis is a user-entered profile, not a verified factory specification. OBD-II support and available modules depend on the exact vehicle and market.");
        Toast.makeText(this,"Vehicle profile saved for this session",Toast.LENGTH_SHORT).show();
    }
    private void decodeVin() {
        String vin=vinInput.getText().toString().trim().toUpperCase(java.util.Locale.US);
        if(vin.length()!=17 || vin.matches(".*[IOQ].*") || !vin.matches("[A-HJ-NPR-Z0-9]{17}")) { message("Check VIN","Enter a 17-character VIN. VINs do not use I, O or Q. Some older or market-specific vehicles may differ."); return; }
        char first=vin.charAt(0); String region;
        if("12345".indexOf(first)>=0) region="North America (broad hint)";
        else if("67".indexOf(first)>=0) region="Oceania / Southeast Asia (broad hint)";
        else if("89".indexOf(first)>=0) region="South America (broad hint)";
        else if(first>='A' && first<='H') region="Africa (broad hint)";
        else if(first>='J' && first<='R') region="Asia (broad hint)";
        else if(first>='S' && first<='Z') region="Europe (broad hint)";
        else region="Unknown region";
        String makeHint=vinMakeHint(vin.substring(0,3));
        String yearHint=vinYearHint(vin.charAt(9));
        uiReport("PRELIMINARY VIN CHECK\nVIN: "+vin+"\nWMI (first 3 characters): "+vin.substring(0,3)+"\nManufacturer hint: "+makeHint+"\nBroad origin hint: "+region+"\nModel-year code (10th character): "+vin.charAt(9)+" → "+yearHint+"\n\nThis offline check does not verify the VIN against a manufacturer database and may not identify exact model, engine, trim or market. Confirm details using registration documents or a trusted VIN lookup.");
    }
    private String vinMakeHint(String wmi) {
        if(wmi.startsWith("JT")) return "Toyota (common prefix; verify exact WMI)";
        if(wmi.startsWith("JN") || wmi.startsWith("1N") || wmi.startsWith("3N")) return "Nissan (common prefix; verify exact WMI)";
        if(wmi.startsWith("JM")) return "Mazda (common prefix; verify exact WMI)";
        if(wmi.startsWith("JA") || wmi.startsWith("JE") || wmi.startsWith("JF")) return "Mitsubishi (possible prefix; verify exact WMI)";
        if(wmi.startsWith("JH")) return "Honda (common prefix; verify exact WMI)";
        if(wmi.startsWith("1F") || wmi.startsWith("3F")) return "Ford (possible prefix; verify exact WMI)";
        if(wmi.startsWith("KM")) return "Hyundai (common prefix; verify exact WMI)";
        if(wmi.startsWith("KNA") || wmi.startsWith("KND")) return "Kia (common prefix; verify exact WMI)";
        if(wmi.startsWith("W")) return "European manufacturer; exact WMI lookup required";
        return "Not identified offline; exact WMI lookup required";
    }
    private String vinYearHint(char code) {
        String codes="ABCDEFGHJKLMNPRSTVWXY123456789";
        int idx=codes.indexOf(code);
        int[] years={1980,1981,1982,1983,1984,1985,1986,1987,1988,1989,1990,1991,1992,1993,1994,1995,1996,1997,1998,1999,2000,2001,2002,2003,2004,2005,2006,2007,2008,2009,2010,2011,2012,2013,2014,2015,2016,2017,2018,2019,2020,2021,2022,2023,2024,2025,2026,2027,2028};
        if(idx<0 || idx>=years.length) return "not decoded";
        return years[idx]+" (year codes repeat in cycles; confirm against vehicle records)";
    }
    private void uiStatus(String text) { runOnUiThread(()->status.setText("Status: "+text)); }
    private void uiReport(String text) { runOnUiThread(()->report.setText(text)); }
    private void message(String title,String body) { new AlertDialog.Builder(this).setTitle(title).setMessage(body).setPositiveButton("OK",null).show(); }
    private void chooseBluetooth() {
        if (Build.VERSION.SDK_INT >= 31 && checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.BLUETOOTH_CONNECT, Manifest.permission.BLUETOOTH_SCAN}, 101); return;
        }
        BluetoothAdapter adapter=BluetoothAdapter.getDefaultAdapter();
        if(adapter==null){message("Bluetooth unavailable","This phone does not provide Bluetooth support.");return;}
        if(!adapter.isEnabled()){message("Turn on Bluetooth","Turn on Bluetooth in your phone settings, pair your ELM327 adapter, then try again.");return;}
        try {
            Set<BluetoothDevice> paired=adapter.getBondedDevices(); ArrayList<BluetoothDevice> devices=new ArrayList<>(); ArrayList<String> names=new ArrayList<>();
            for(BluetoothDevice d:paired){devices.add(d); names.add((d.getName()==null?"Bluetooth device":d.getName())+"\n"+d.getAddress());}
            if(devices.isEmpty()){message("No paired adapters","Open Bluetooth settings and pair your ELM327 adapter first.");return;}
            new AlertDialog.Builder(this).setTitle("Choose paired OBD-II adapter").setItems(names.toArray(new String[0]),(dialog,which)->connectBluetooth(devices.get(which))).setNegativeButton("Cancel",null).show();
        } catch(SecurityException e){message("Bluetooth permission required","Allow Nearby devices/Bluetooth permission, then retry.");}
    }
    private void connectBluetooth(BluetoothDevice device) {
        uiStatus("Connecting to Bluetooth adapter..."); new Thread(()->{
            try { BluetoothSocket s=device.createRfcommSocketToServiceRecord(SPP_UUID); s.connect(); bluetoothSocket=s; input=s.getInputStream(); output=s.getOutputStream(); connected=true; uiStatus("Connected by Bluetooth to "+device.getName()); initializeElm(); }
            catch(Exception e){connected=false; uiStatus("Bluetooth connection failed: "+e.getMessage());}
        }).start();
    }
    private void connectWifi() {
        String host=wifiHost.getText().toString().trim(); int port;
        try{port=Integer.parseInt(wifiPort.getText().toString().trim()); if(port<1||port>65535)throw new Exception();}catch(Exception e){message("Check port","Enter a valid port from 1 to 65535.");return;}
        if(host.isEmpty()){message("Check IP address","Enter the Wi-Fi adapter's IP address.");return;}
        uiStatus("Connecting to Wi-Fi adapter..."); final int p=port; new Thread(()->{
            try { Socket s=new Socket(); s.connect(new InetSocketAddress(host,p),5000); wifiSocket=s; input=s.getInputStream(); output=s.getOutputStream(); connected=true; uiStatus("Connected by Wi-Fi to "+host+":"+p); initializeElm(); }
            catch(Exception e){connected=false;uiStatus("Wi-Fi connection failed: "+e.getMessage()+". Check adapter IP, port and same Wi-Fi network.");}
        }).start();
    }
    private synchronized String command(String cmd) throws Exception {
        if(!connected||output==null||input==null) throw new Exception("Connect an OBD-II adapter first.");
        while(input.available()>0) input.read(); output.write((cmd+"\r").getBytes(StandardCharsets.US_ASCII)); output.flush();
        StringBuilder out=new StringBuilder(); long end=System.currentTimeMillis()+3500;
        while(System.currentTimeMillis()<end){ if(input.available()>0){int c=input.read(); if(c<0)break; if(c=='>' )break; if(c!='\r'&&c!='\n')out.append((char)c);} else {Thread.sleep(40);} }
        return out.toString().trim();
    }
    private void initializeElm(){try{command("ATZ");Thread.sleep(900);command("ATE0");command("ATL0");command("ATS0");command("ATH0");String r=command("0100");uiReport("Adapter initialized. Vehicle protocol response to 0100:\n"+r+"\n\nIf the response says UNABLE TO CONNECT or NO DATA, switch ignition on and check adapter compatibility.");}catch(Exception e){uiReport("Adapter connected, but initialization/vehicle communication failed: "+e.getMessage());}}
    private void sendObd(String cmd,String title){ if(!connected){message("Scanner not connected","Connect a compatible Bluetooth or Wi-Fi ELM327 adapter first.");return;} uiStatus("Requesting "+title+"..."); new Thread(()->{try{String r=command(cmd);uiReport(title+"\nOBD-II command: "+cmd+"\nRaw adapter response:\n"+r+"\n\nNote: raw responses are shown in this version; manufacturer-specific interpretation may require enhanced diagnostics.");uiStatus("Connected; request completed.");}catch(Exception e){uiReport(title+" failed: "+e.getMessage());}}).start(); }
    private void readLiveData(){ if(!connected){message("Scanner not connected","Connect an OBD-II adapter first.");return;} uiStatus("Reading live engine data..."); new Thread(()->{try{String rpm=command("010C");String speed=command("010D");String temp=command("0105");String load=command("0104");uiReport("LIVE ENGINE DATA\nEngine RPM (010C): "+rpm+"\nVehicle speed (010D): "+speed+"\nCoolant temperature (0105): "+temp+"\nCalculated engine load (0104): "+load+"\n\nValues are raw adapter responses in this version. Confirm the engine is running when appropriate and keep attention on the road; never read the screen while driving.");}catch(Exception e){uiReport("Live data request failed: "+e.getMessage());}}).start(); }
    private void analyseSymptoms(){String s=symptoms.getText().toString().toLowerCase().trim(); if(s.isEmpty()){message("Describe the problem","Enter the vehicle symptoms first.");return;} StringBuilder r=new StringBuilder("MASTER VEHICLE DOCTOR AI — PRELIMINARY SYMPTOM REPORT\n\nSymptoms entered: ").append(symptoms.getText().toString()).append("\n\nLikely areas to check (not a confirmed diagnosis):\n");
        if(s.contains("overheat")||s.contains("hot")||s.contains("temperature"))r.append("1. Cooling system: coolant level/leaks, radiator fan, thermostat, radiator blockage, water pump. Stop driving if temperature is high.\n");
        if(s.contains("crank")||s.contains("start")||s.contains("starting")||s.contains("won't start")||s.contains("will not start"))r.append("1. Starting/no-start: battery voltage and terminals, starter circuit, fuel supply, ignition, immobilizer and crank/cam sensors. Note whether engine cranks.\n");
        if(s.contains("rough")||s.contains("misfire")||s.contains("shake")||s.contains("vibrat"))r.append("1. Rough running: scan for DTCs, inspect ignition coils/plugs, intake leaks, fuel delivery and engine mounts.\n");
        if(s.contains("smoke")||s.contains("burn"))r.append("1. Smoke/burning smell: stop safely if smoke is heavy or there is a fire risk. Check oil/coolant leaks and wiring only when safe.\n");
        if(s.contains("brake")||s.contains("steering"))r.append("1. Brake/steering concern: safety-critical. Do not drive if braking or steering is impaired; arrange professional inspection.\n");
        if(s.contains("battery")||s.contains("light")||s.contains("electrical"))r.append("1. Electrical: battery condition, charging voltage, fuses, grounds and alternator output.\n");
        r.append("\nRecommended next steps:\n• Record dashboard warning lights and all fault codes before clearing anything.\n• Check fluid levels only using the owner's manual and safe procedures.\n• Confirm diagnosis with measurements and a qualified technician.\n\nThis is rule-based guidance, not a cloud AI diagnosis. Parts/labour prices depend on vehicle, location and parts quality; no estimate is supplied without vehicle details."); uiReport(r.toString()); }
    @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results){super.onRequestPermissionsResult(requestCode,permissions,results);if(requestCode==101){if(results.length>0&&results[0]==PackageManager.PERMISSION_GRANTED)chooseBluetooth();else message("Permission needed","Allow Bluetooth/Nearby devices permission to connect an adapter.");}}
    @Override protected void onDestroy(){super.onDestroy();connected=false;try{if(bluetoothSocket!=null)bluetoothSocket.close();}catch(Exception ignored){}try{if(wifiSocket!=null)wifiSocket.close();}catch(Exception ignored){}}
}
