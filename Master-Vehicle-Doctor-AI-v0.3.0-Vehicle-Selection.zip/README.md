# Master Vehicle Doctor AI — Diagnostic Edition v0.2.0

Android starter project with an OBD-II ELM327 Bluetooth classic and Wi-Fi TCP connection path, Mode 03 trouble-code requests, basic live-data requests, and rule-based symptom guidance.

## Build
Use JDK 17 and Android Gradle Plugin 8.7.3 / Gradle 8.9. Run `gradle assembleDebug`.

## Important limitations
- Requires a compatible ELM327-style OBD-II adapter and a vehicle that supports the requested standard OBD-II services.
- Bluetooth adapters must be paired in Android Bluetooth settings before connecting. Wi-Fi adapter IP and port vary by device.
- This version displays raw OBD responses; it does not yet decode every DTC or convert all live-data responses into engineering units.
- USB serial communication, enhanced ABS/airbag/transmission/manufacturer modules, stored vehicle history, verified parts/labour pricing, and cloud-based generative AI are not implemented yet.
- Symptom advice is preliminary and must not replace a qualified mechanic. Do not clear codes before recording them.


## v0.3.0 Vehicle Selection
- Manual make/model/year vehicle profile entry.
- Basic offline 17-character VIN format check with limited WMI hints and model-year code hint.
- VIN results are preliminary and are not a verified factory database lookup.
- Real OBD-II hardware communication depends on adapter compatibility and vehicle support.
